exports.privacyPolicyPage = async (req, res) => {
    res.render("privacy-policy");
};

exports.termPage = async (req, res) => {
    res.render("terms");
};