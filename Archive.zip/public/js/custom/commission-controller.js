// $("#saveCommission").click(function (e) {
//     //e.preventDefault()
//     let commission = $("#commission").val();
//     console.log("COM ", commission)

//     $.ajax({
//         url: '/commission',
//         method: "POST",
//         data: { commission },
//         success: function (response) {
//             // $.LoadingOverlay("hide");
//         $("#commission").val(response.commission.commission);

//         },
//         error: function (e) {
//             console.log("Error ", e);
//             // $.LoadingOverlay("hide");
//         },
//     });
// });

