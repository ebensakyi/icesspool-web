module.exports.route = app => {




    app.get("/aboutICesspool", function(req, res, next) {
       res.render('aboutICesspool') 
      });
    
    
    
    }