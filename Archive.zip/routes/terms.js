module.exports.route = app => {




app.get("/terms", function(req, res, next) {
   res.render('terms') 
  });



}