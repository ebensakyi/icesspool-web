module.exports = {
    regions: ['', 'GAR', 'ASR', 'ESR', 'WSR', 'CTR', 'AHR', 'BNR', 'BER', 'NTR', 'NER', 'SVR', 'UER', 'UWR', 'VTR', 'OTR', 'WNR']
}