export const append_233 = (phone: string ) => {
  const char = phone[0];
  const replaced = phone.replace(char, "233");
  return replaced;
};
