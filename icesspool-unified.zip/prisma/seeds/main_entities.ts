export const entities = [
  {
    name: "iCesspool",
  },
  {
    name: "MMDA",
  },
  {
    name: "Operators",
  },

];
