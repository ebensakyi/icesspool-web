export const regions = [
    {
      name: "Greater Accra",
      latitude:  5.736477,
      longitude: -0.104436,
    },  {
      name: "Northern",
      latitude: 9.428353,
      longitude:-0.848357,

    },
    {
      name: "Ashanti",
      latitude: 6.705764,
      longitude: -1.609930,

    },
  
   
  ];
  