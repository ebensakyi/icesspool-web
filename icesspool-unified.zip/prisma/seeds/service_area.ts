export const serviceAreas = [
  {
    name: "Greater Accra Area",
    lat1:5.472543,
    lng1: -0.420407,
    lat2:5.797806,
    lng2:-0.549497,
    lat3:6.116055,
    lng3: 0.216800,
    lat4:5.781411,
    lng4:0.694705,
   
    regionId: 1,
  },

  {
    name: "Tamale",
    lat1:5.472543,
    lng1: -0.420407,
    lat2:5.797806,
    lng2:-0.549497,
    lat3:6.116055,
    lng3: 0.216800,
    lat4:5.781411,
    lng4:0.694705,
   
    regionId: 2,
  },

  {
    name: "Sanerigu",
    lat1:5.472543,
    lng1: -0.420407,
    lat2:5.797806,
    lng2:-0.549497,
    lat3:6.116055,
    lng3: 0.216800,
    lat4:5.781411,
    lng4:0.694705,
   
    regionId: 2,
  },
 
];
