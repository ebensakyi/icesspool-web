export const services = [
    {
      name: "Desludging",
    },
    {
      name: "Water Request",
    },
    {
      name: "Bio-digester",
    },
  
  ];
  