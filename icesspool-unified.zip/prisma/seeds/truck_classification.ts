export const truckClassification = [
  {
    name: "Mini",
    tankCapacity: 4.5,
    serviceId: 1,
    serviceAreaId:2
  },
  {
    name: "Small",
    tankCapacity: 7.5,
    serviceId: 1,
    serviceAreaId:2
  },
  {
    name: "Single",
    tankCapacity: 12,
    serviceId: 1,
    serviceAreaId:2

  },
  {
    name: "Medium",
    tankCapacity: 18,
    serviceId: 1,
    serviceAreaId:1

  },
  {
    name: "Double",
    tankCapacity: 24,
    serviceId: 1,
    serviceAreaId:1

  },
];
