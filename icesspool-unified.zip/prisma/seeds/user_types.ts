export const userTypes = [
  {
    name: "System admin",
  },
  {
    name: "Regional admin",
  },
  {
    name: "Scanners",
  },
  {
    name: "Operators",
  },
  {
    name: "Customer",
  },
];
