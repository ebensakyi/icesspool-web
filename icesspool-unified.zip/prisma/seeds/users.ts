export const users = [
    {
      surname: "System admin",
      otherNames:"",
      email:"",
      phoneNumber:"0543212322",
      userTypeId:1,
      password:"$2a$12$.8ZoO0Gm0evbFkQ0BX5XduX7OrWeyqZBvujjfstSFE3S7xFalGmVW"
    },
   
  ];
  