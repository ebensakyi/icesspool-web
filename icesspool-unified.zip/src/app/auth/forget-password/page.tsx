
import ForgetPassword from "@/src/components/forget-password/ForgetPassword";

export default async function Page() {

  return <ForgetPassword/>

}
