import ResetPassword from "@/src/components/reset-password/ResetPassword";


  export default async function Page() {

  return <ResetPassword/>

}
